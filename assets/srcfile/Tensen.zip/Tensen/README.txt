!!!! A FAIRE AVANT D UTILISER TENSEN !!!!

pour une utilisation complete et fonctionnelle de Tensen merci de : 

Vérifier si vous possédez les logiciels : 

Nmap
hashcat
wireshark
netcat


Copier le code en dessous en remplacant le chemin d'accès a la vm par le votre:

:PAGE_3
"C:\Program Files (x86)\VMware\VMware Workstation\vmrun.exe" start "C:\votre_chemin_d'accès_a_la_vm"
goto MENU



