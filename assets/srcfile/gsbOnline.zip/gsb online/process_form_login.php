<?php
session_start();

$serveur = "sql209.infinityfree.com";
$utilisateur = "if0_38598703";
$mdpBDD = "mdH5kK0uRvk9";
$nomBDD = "if0_38598703_bisounours";

try {
    $connexion = new PDO("mysql:host=$serveur;dbname=$nomBDD;charset=utf8", $utilisateur, $mdpBDD);
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST["login"];
    $password = $_POST["password"];

    // Vérifie que les champs ne sont pas vides
    if (empty($login) || empty($password)) {
        header("Location: login.php?error=empty_fields");
        exit();
    }

    // Récupération de l'utilisateur par son email
    $requete = $connexion->prepare("
        SELECT u.*, r.id_role, r.role 
        FROM user u
        JOIN role r ON u.role = r.id_role
        WHERE u.email = :login
    ");
    $requete->bindParam(':login', $login);
    $requete->execute();

    $utilisateur = $requete->fetch(PDO::FETCH_ASSOC);

    if ($utilisateur && password_verify($password, $utilisateur['password'])) {
        $_SESSION['utilisateur'] = $utilisateur;
        header("Location: dashboard.php");
        exit();
    } else {
        header("Location: login.php?error=invalid_credentials");
        exit();
    }
}
?>
