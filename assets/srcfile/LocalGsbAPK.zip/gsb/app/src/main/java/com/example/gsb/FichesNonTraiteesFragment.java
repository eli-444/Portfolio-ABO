package com.example.gsb;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class FichesNonTraiteesFragment extends Fragment {

    private LinearLayout container;

    public FichesNonTraiteesFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup containerGroup,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fiches_non_traitees, containerGroup, false);
        container = view.findViewById(R.id.fichesNonTraiteesContainer);
        loadFiches();
        return view;
    }

    private void loadFiches() {
        String url = "http://192.168.136.1:8080/get_fiches_nontraiteesapi.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        Log.e("RESPONSE_RAW", response);
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            JSONArray fiches = json.getJSONArray("fiches");
                            for (int i = 0; i < fiches.length(); i++) {
                                JSONObject fiche = fiches.getJSONObject(i);
                                addFicheView(fiche);
                            }
                        } else {
                            Toast.makeText(getContext(), "Aucune fiche non traitée", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    if (isAdded()) {
                        Toast.makeText(requireContext(), "Erreur réseau", Toast.LENGTH_SHORT).show();
                    }
                });

        Volley.newRequestQueue(requireContext()).add(request);
    }

    private void addFicheView(JSONObject fiche) {
        try {
            int id = fiche.getInt("id_fiche");
            String date = fiche.getString("date");
            String commentaire = fiche.isNull("commentaire") ? "(aucun commentaire)" : fiche.getString("commentaire");
            String nom = fiche.getString("fname") + " " + fiche.getString("lname");

            LinearLayout bloc = new LinearLayout(getContext());
            bloc.setOrientation(LinearLayout.VERTICAL);
            bloc.setPadding(20, 20, 20, 20);
            bloc.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
            bloc.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            TextView info = new TextView(getContext());
            info.setText("📄 Fiche #" + id +
                    "\n👤 Nom : " + nom +
                    "\n📅 Date : " + date +
                    "\n📝 Commentaire : " + commentaire);

            Button btnValider = new Button(getContext());
            btnValider.setText("✅ Valider");
            btnValider.setOnClickListener(v -> updateEtat(id, "Validée"));

            Button btnRefuser = new Button(getContext());
            btnRefuser.setText("❌ Refuser");
            btnRefuser.setOnClickListener(v -> updateEtat(id, "Refusée"));

            bloc.addView(info);
            bloc.addView(btnValider);
            bloc.addView(btnRefuser);
            container.addView(bloc);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Erreur d'affichage", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateEtat(int idFiche, String nouveauStatut) {
        String url = "http://192.168.136.1:8080/update_etat_ficheapi.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(getContext(), "Fiche " + nouveauStatut, Toast.LENGTH_SHORT).show();
                    container.removeAllViews();
                    loadFiches(); // recharge la liste
                },
                error -> {
                    Toast.makeText(getContext(), "Erreur mise à jour", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected java.util.Map<String, String> getParams() {
                java.util.Map<String, String> params = new java.util.HashMap<>();
                params.put("id_fiche", String.valueOf(idFiche));
                params.put("status", nouveauStatut);
                params.put("commentaireComptable", "");
                return params;
            }
        };

        Volley.newRequestQueue(requireContext()).add(request);
    }
}
