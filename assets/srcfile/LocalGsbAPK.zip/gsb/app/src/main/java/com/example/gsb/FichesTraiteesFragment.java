package com.example.gsb;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class FichesTraiteesFragment extends Fragment {

    private LinearLayout container;

    public FichesTraiteesFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup containerGroup,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fiches_traitees, containerGroup, false);
        container = view.findViewById(R.id.fichesTraiteesContainer);
        loadFiches();
        return view;
    }

    private void loadFiches() {
        String url = "http://192.168.136.1:8080/get_fiches_traiteesapi.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        Log.e("RESPONSE_RAW", response);
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            JSONArray fiches = json.getJSONArray("fiches");
                            for (int i = 0; i < fiches.length(); i++) {
                                JSONObject fiche = fiches.getJSONObject(i);
                                addFicheView(fiche);
                            }
                        } else {
                            Toast.makeText(getContext(), "Aucune fiche traitée", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(requireContext()).add(request);
    }

    private void addFicheView(JSONObject fiche) {
        try {
            int id = fiche.getInt("id_fiche");
            String date = fiche.getString("date");
            String commentaire = fiche.getString("commentaire");
            String etat = fiche.getString("status");
            String commentaireComptable = fiche.getString("commentaireComptable");
            String nom = fiche.getString("fname") + " " + fiche.getString("lname");

            TextView tv = new TextView(getContext());
            tv.setText("Fiche #" + id +
                    "\nNom : " + nom +
                    "\nDate : " + date +
                    "\nCommentaire visiteur : " + commentaire +
                    "\nDécision : " + etat +
                    "\nCommentaire du comptable : " + commentaireComptable);
            tv.setPadding(20, 20, 20, 20);
            tv.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 16, 0, 16);

            container.addView(tv, params);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
