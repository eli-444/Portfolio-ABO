package com.example.gsb;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class DashboardComptableActivity extends AppCompatActivity {

    private Button btnNonTraitees, btnTraitees, btnProfile, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_comptable);

        SharedPreferences prefs = getSharedPreferences("GSB_PREFS", MODE_PRIVATE);
        String role = prefs.getString("type", "visiteur");
        if (!"comptable".equals(role)) {
            Toast.makeText(this, "Accès refusé", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        btnNonTraitees = findViewById(R.id.btnNonTraitees);
        btnTraitees = findViewById(R.id.btnTraitees);
        btnProfile = findViewById(R.id.btnProfile);
        btnLogout = findViewById(R.id.btnLogout);

        loadFragment(new FichesNonTraiteesFragment());

        btnNonTraitees.setOnClickListener(v -> loadFragment(new FichesNonTraiteesFragment()));
        btnTraitees.setOnClickListener(v -> loadFragment(new FichesTraiteesFragment()));
        btnProfile.setOnClickListener(v -> loadFragment(new ProfileComptableFragment()));

        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }
}
