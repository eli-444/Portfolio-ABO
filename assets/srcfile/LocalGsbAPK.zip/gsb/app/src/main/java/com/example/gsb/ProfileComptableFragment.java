package com.example.gsb;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileComptableFragment extends Fragment {

    private EditText etNom, etPrenom;
    private Button btnSave;

    public ProfileComptableFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile_comptable, container, false);

        etNom = view.findViewById(R.id.etNom);
        etPrenom = view.findViewById(R.id.etPrenom);
        btnSave = view.findViewById(R.id.btnSave);

        loadProfile();

        btnSave.setOnClickListener(v -> updateProfile());

        return view;
    }

    private void loadProfile() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("GSB_PREFS", getContext().MODE_PRIVATE);
        String userId = prefs.getString("id", null);
        if (userId == null) return;

        String url = "http://192.168.136.1:8080/get_userapi.php?id=" + userId;

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            JSONObject user = json.getJSONObject("user");
                            etNom.setText(user.getString("lname"));
                            etPrenom.setText(user.getString("fname"));
                        } else {
                            Toast.makeText(getContext(), "Utilisateur introuvable", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(requireContext()).add(request);
    }

    private void updateProfile() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("GSB_PREFS", getContext().MODE_PRIVATE);
        String userId = prefs.getString("id", null);
        if (userId == null) return;

        String lname = etNom.getText().toString().trim();
        String fname = etPrenom.getText().toString().trim();

        String url = "http://192.168.136.1:8080/update_userapi.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            Toast.makeText(getContext(), "Profil mis à jour", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Erreur lors de la mise à jour", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id_user", userId);
                params.put("lname", lname);
                params.put("fname", fname);
                return params;
            }
        };

        Volley.newRequestQueue(requireContext()).add(request);
    }
}
