package com.example.gsb;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FicheDetailComptableFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvTotalGlobal, tvHeader;
    private List<Frais> listeFrais = new ArrayList<>();
    private FraisComptableAdapter adapter;

    private int idFiche;
    private String date, commentaire;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fiche_detail_comptable, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewFrais);
        progressBar = view.findViewById(R.id.progressBar);
        tvTotalGlobal = view.findViewById(R.id.tvTotalGlobal);
        tvHeader = view.findViewById(R.id.tvHeader);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new FraisComptableAdapter(listeFrais);
        recyclerView.setAdapter(adapter);

        if (getArguments() != null) {
            idFiche = getArguments().getInt("id_fiche");
            date = getArguments().getString("date", "");
            commentaire = getArguments().getString("commentaire", "");
            tvHeader.setText("Fiche #" + idFiche + " - " + date + "\n" + commentaire);
        }

        chargerDetailsFiche();
        return view;
    }

    private void chargerDetailsFiche() {
        progressBar.setVisibility(View.VISIBLE);
        String url = "http://10.213.34.93:8080/get_fiche_detailapi.php?id_fiche=" + idFiche;

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            JSONArray fraisArray = json.getJSONArray("frais");
                            listeFrais.clear();

                            double totalGlobal = 0.0;

                            for (int i = 0; i < fraisArray.length(); i++) {
                                JSONObject item = fraisArray.getJSONObject(i);

                                String type = item.getString("type_frais");
                                int quantite = item.getInt("quantite");
                                double pu = item.getDouble("prix_unitaire");
                                double total = item.getDouble("total_frais");

                                totalGlobal += total;
                                listeFrais.add(new Frais(type, quantite, pu, total));
                            }

                            adapter.notifyDataSetChanged();
                            tvTotalGlobal.setText(String.format("Total global : %.2f €", totalGlobal));
                        }
                    } catch (Exception e) {
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    } finally {
                        progressBar.setVisibility(View.GONE);
                    }
                },
                error -> {
                    Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                });

        Volley.newRequestQueue(requireContext()).add(request);
    }
}
