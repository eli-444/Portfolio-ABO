package com.example.gsb;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class HistoriqueFraisFragment extends Fragment {

    private LinearLayout fichesContainer;

    private final String GET_FICHES_URL = "http://192.168.136.1:8080/get_fichesapi.php";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_historique_frais, container, false);
        fichesContainer = view.findViewById(R.id.fichesContainer);

        loadFiches();
        return view;
    }

    private void loadFiches() {
        SharedPreferences prefs = requireContext().getSharedPreferences("GSB_PREFS", Context.MODE_PRIVATE);
        String userId = prefs.getString("id", null);

        if (userId == null) {
            Toast.makeText(getContext(), "Utilisateur non connecté", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest request = new StringRequest(Request.Method.POST, GET_FICHES_URL,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        boolean success = json.getBoolean("success");

                        if (success) {
                            JSONArray fiches = json.getJSONArray("fiches");

                            for (int i = 0; i < fiches.length(); i++) {
                                JSONObject fiche = fiches.getJSONObject(i);
                                String date = fiche.getString("date");
                                String commentaire = fiche.getString("commentaire");
                                Integer idFiche = fiche.getInt("id_fiche");

                                addFicheView(date, commentaire, idFiche);
                            }
                        } else {
                            Toast.makeText(getContext(), "Aucune fiche trouvée", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur de parsing JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected java.util.Map<String, String> getParams() {
                java.util.Map<String, String> params = new java.util.HashMap<>();
                params.put("id_user", userId);
                return params;
            }
        };

        Volley.newRequestQueue(requireContext()).add(request);
    }

    private void addFicheView(String date, String commentaire, Integer id_fiche) {
        TextView textView = new TextView(getContext());
        textView.setText("📅 " + date + "\n📝 " + commentaire);
        textView.setPadding(16, 16, 16, 16);
        textView.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 16, 0, 16);

        textView.setOnClickListener(v -> {
            FicheDetailFragment detailFragment = new FicheDetailFragment();
            Bundle args = new Bundle();
            args.putInt("id_fiche", id_fiche);
            args.putString("date", date);
            args.putString("commentaire", commentaire);

            detailFragment.setArguments(args);

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainer, detailFragment)
                    .addToBackStack(null)
                    .commit();
        });

        fichesContainer.addView(textView, params);
    }
}
