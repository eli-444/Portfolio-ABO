package com.example.gsb;

import android.view.View;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class DashboardActivity extends AppCompatActivity {

    private Button btnCreateFrais, btnFichesFrais, btnProfile, btnLogout, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        SharedPreferences prefs = getSharedPreferences("GSB_PREFS", MODE_PRIVATE);
        String type = prefs.getString("type", null);

        if (!"visiteur".equals(type)) {
            Toast.makeText(this, "Accès refusé", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialisation des boutons
        btnCreateFrais = findViewById(R.id.btnCreateFrais);
        btnFichesFrais = findViewById(R.id.btnViewFiches);
        btnProfile     = findViewById(R.id.btnProfile);
        btnLogout      = findViewById(R.id.btnLogout);
        btnBack        = findViewById(R.id.btnBack);

        // Listeners
        btnCreateFrais.setOnClickListener(v -> loadFragment(new CreateFraisFragment()));
        btnFichesFrais.setOnClickListener(v -> loadFragment(new HistoriqueFraisFragment()));
        btnProfile.setOnClickListener(v -> loadFragment(new ProfileFragment()));
        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
        btnBack.setOnClickListener(v -> onBackPressed());

        //affichage par défaut
        loadFragment(new CreateFraisFragment());
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit();

        btnCreateFrais.setVisibility(View.GONE);
        btnFichesFrais.setVisibility(View.GONE);
        btnProfile.setVisibility(View.GONE);
        btnLogout.setVisibility(View.GONE);
        btnBack.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();

            // afficher les boutons apres avoir été caché avec View.GONE
            btnCreateFrais.setVisibility(View.VISIBLE);
            btnFichesFrais.setVisibility(View.VISIBLE);
            btnProfile.setVisibility(View.VISIBLE);
            btnLogout.setVisibility(View.VISIBLE);
            btnBack.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }
}
