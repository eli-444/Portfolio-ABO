package com.example.gsb;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class DashboardAdminActivity extends AppCompatActivity {

    private Button btnManageUsers, btnStats, btnLogs, btnProfile, btnLogout, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_admin);

        SharedPreferences prefs = getSharedPreferences("GSB_PREFS", MODE_PRIVATE);
        String role = prefs.getString("role", null);

        if (!"3".equals(role)) {
            Toast.makeText(this, "Accès refusé", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        btnManageUsers = findViewById(R.id.btnManageUsers);
        btnStats       = findViewById(R.id.btnStats);
        btnLogs        = findViewById(R.id.btnLogs);
        btnProfile     = findViewById(R.id.btnProfile);
        btnLogout      = findViewById(R.id.btnLogout);
        btnBack        = findViewById(R.id.btnBack);

        btnManageUsers.setOnClickListener(v -> loadFragment(new AdminUserFragment()));
        btnStats.setOnClickListener(v -> loadFragment(new AdminStatsFragment()));
        btnLogs.setOnClickListener(v -> loadFragment(new AdminLogsFragment()));
        btnProfile.setOnClickListener(v -> loadFragment(new ProfileFragment()));

        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        btnBack.setOnClickListener(v -> onBackPressed());

        loadFragment(new AdminUserFragment()); // fragment par défaut au démarrage
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit();


        btnManageUsers.setVisibility(View.GONE);
        btnStats.setVisibility(View.GONE);
        btnLogs.setVisibility(View.GONE);
        btnProfile.setVisibility(View.GONE);
        btnLogout.setVisibility(View.GONE);
        btnBack.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
            btnManageUsers.setVisibility(View.VISIBLE);
            btnStats.setVisibility(View.VISIBLE);
            btnLogs.setVisibility(View.VISIBLE);
            btnProfile.setVisibility(View.VISIBLE);
            btnLogout.setVisibility(View.VISIBLE);
            btnBack.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }
}
