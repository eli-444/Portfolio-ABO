package com.example.gsb;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private Context context;
    private List<User> userList;
    private OnUserDeleteListener deleteListener;

    public interface OnUserDeleteListener {
        void onDeleteClick(int userId);
    }

    public UserAdapter(Context context, List<User> userList, OnUserDeleteListener deleteListener) {
        this.context = context;
        this.userList = userList;
        this.deleteListener = deleteListener;
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView name, email, role;
        Button btnDelete;

        public UserViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.txtName);
            email = view.findViewById(R.id.txtEmail);
            role = view.findViewById(R.id.txtRole);
            btnDelete = view.findViewById(R.id.btnDelete);
        }
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        User u = userList.get(position);
        holder.name.setText(u.getFname() + " " + u.getLname());
        holder.email.setText(u.getEmail());
        holder.role.setText(u.getRoleLabel());

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteClick(u.getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }
}
