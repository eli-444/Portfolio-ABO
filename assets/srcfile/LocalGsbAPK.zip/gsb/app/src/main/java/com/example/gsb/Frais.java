package com.example.gsb;

public class Frais {
    private String typeFrais;
    private int quantite;
    private double prixUnitaire;
    private double totalLigne;

    public Frais(String typeFrais, int quantite, double prixUnitaire, double totalLigne) {
        this.typeFrais = typeFrais;
        this.quantite = quantite;
        this.prixUnitaire = prixUnitaire;
        this.totalLigne = totalLigne;
    }

    public String getTypeFrais() { return typeFrais; }
    public int getQuantite() { return quantite; }
    public double getPrixUnitaire() { return prixUnitaire; }
    public double getTotalLigne() { return totalLigne; }
}
