package com.example.gsb;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FraisComptableAdapter extends RecyclerView.Adapter<FraisComptableAdapter.FraisViewHolder> {

    private final List<Frais> fraisList;

    public FraisComptableAdapter(List<Frais> fraisList) {
        this.fraisList = fraisList;
    }

    @NonNull
    @Override
    public FraisViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_frais_comptable, parent, false);
        return new FraisViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FraisViewHolder holder, int position) {
        Frais f = fraisList.get(position);
        holder.tvType.setText("🗂 " + f.getTypeFrais());
        holder.tvQuantite.setText("Quantité : " + f.getQuantite());
        holder.tvPU.setText(String.format("PU : %.2f €", f.getPrixUnitaire()));
        holder.tvTotal.setText(String.format("Total : %.2f €", f.getTotalLigne()));
    }

    @Override
    public int getItemCount() {
        return fraisList.size();
    }

    static class FraisViewHolder extends RecyclerView.ViewHolder {
        TextView tvType, tvQuantite, tvPU, tvTotal;

        public FraisViewHolder(@NonNull View itemView) {
            super(itemView);
            tvType = itemView.findViewById(R.id.tvTypeFrais);
            tvQuantite = itemView.findViewById(R.id.tvQuantite);
            tvPU = itemView.findViewById(R.id.tvPU);
            tvTotal = itemView.findViewById(R.id.tvTotal);
        }
    }
}
