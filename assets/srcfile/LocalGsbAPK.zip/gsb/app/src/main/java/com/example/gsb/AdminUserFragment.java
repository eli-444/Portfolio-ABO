package com.example.gsb;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminUserFragment extends Fragment {

    private EditText etNom, etPrenom, etEmail, etPassword, etRole;
    private Button btnCreate;
    private RecyclerView recyclerView;
    private List<User> userList = new ArrayList<>();
    private UserAdapter adapter;

    public AdminUserFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_user, container, false);

        // Initialisation des vues
        recyclerView = view.findViewById(R.id.recyclerViewUsers);
        etNom = view.findViewById(R.id.etNom);
        etPrenom = view.findViewById(R.id.etPrenom);
        etEmail = view.findViewById(R.id.etEmail);
        etPassword = view.findViewById(R.id.etPassword);
        etRole = view.findViewById(R.id.etRole);
        btnCreate = view.findViewById(R.id.btnCreateUser);

        // Setup recyclerview
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new UserAdapter(getContext(), userList, this::supprimerUtilisateur);
        recyclerView.setAdapter(adapter);

        // Actions
        btnCreate.setOnClickListener(v -> creerUtilisateur());

        chargerUtilisateurs();

        return view;
    }

    private void chargerUtilisateurs() {
        String url = "http://192.168.136.1:8080/get_all_usersapi.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        Log.e("API_USER",response);
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            JSONArray users = json.getJSONArray("users");
                            userList.clear();
                            for (int i = 0; i < users.length(); i++) {
                                JSONObject u = users.getJSONObject(i);
                                userList.add(new User(
                                        u.getInt("id_user"),
                                        u.getString("fname"),
                                        u.getString("lname"),
                                        u.getString("email"),
                                        u.getInt("role"),
                                        u.getString("role_label")
                                ));
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getContext(), "Aucun utilisateur trouvé", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(requireContext()).add(request);
    }

    private void supprimerUtilisateur(int userId) {
        String url = "http://192.168.136.1:8080/delete_userapi.php?id=" + userId;

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    Toast.makeText(getContext(), "Utilisateur supprimé", Toast.LENGTH_SHORT).show();
                    chargerUtilisateurs();
                },
                error -> Toast.makeText(getContext(), "Erreur suppression", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(requireContext()).add(request);
    }

    private void creerUtilisateur() {
        String nom = etNom.getText().toString().trim();
        String prenom = etPrenom.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String roleStr = etRole.getText().toString().trim();

        if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || password.isEmpty() || roleStr.isEmpty()) {
            Toast.makeText(getContext(), "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "http://192.168.136.1:8080/create_userapi.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            Toast.makeText(getContext(), "Utilisateur créé", Toast.LENGTH_SHORT).show();
                            chargerUtilisateurs();
                            etNom.setText("");
                            etPrenom.setText("");
                            etEmail.setText("");
                            etPassword.setText("");
                            etRole.setText("");
                        } else {
                            Toast.makeText(getContext(), "Erreur : " + json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur de création", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("fname", prenom);
                params.put("lname", nom);
                params.put("email", email);
                params.put("password", password);
                params.put("role", roleStr);
                return params;
            }
        };

        Volley.newRequestQueue(requireContext()).add(request);
    }
}
