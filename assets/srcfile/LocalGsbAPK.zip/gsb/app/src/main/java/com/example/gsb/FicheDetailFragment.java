package com.example.gsb;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;

public class FicheDetailFragment extends Fragment {

    public FicheDetailFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fiche_detail, container, false);

        TextView tvDate = view.findViewById(R.id.tvDate);
        TextView tvCommentaire = view.findViewById(R.id.tvCommentaire);

        Bundle args = getArguments();
        if (args != null) {
            int idFiche = args.getInt("id_fiche", 0);
            String date = args.getString("date", "Date inconnue");
            String commentaire = args.getString("commentaire", "Aucun commentaire");

            tvDate.setText("Date : " + date);
            tvCommentaire.setText("Commentaire :\n" + commentaire);

            if (idFiche > 0) {
                loadFicheDetails(idFiche, view);
            }
        }


        return view;
    }
    private void loadFicheDetails(int idFiche, View rootView) {
        String url = "http://192.168.136.1:8080/get_fiche_detailapi.php?id_fiche=" + idFiche;

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            JSONArray details = json.getJSONArray("frais");
                            StringBuilder builder = new StringBuilder();

                            for (int i = 0; i < details.length(); i++) {
                                JSONObject item = details.getJSONObject(i);
                                builder.append("- ")
                                        .append(item.getString("type_frais"))
                                        .append(" : ")
                                        .append(item.getString("quantite"))
                                        .append(" × ")
                                        .append(item.getString("prix_unitaire"))
                                        .append(" € = ")
                                        .append(item.getString("total_frais"))
                                        .append(" €\n");
                            }

                            builder.append("\nTotal global : ")
                                    .append(json.getString("total"))
                                    .append(" €");

                            TextView tvFrais = rootView.findViewById(R.id.tvFrais);
                            tvFrais.setText(builder.toString());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    error.printStackTrace();
                });

        Volley.newRequestQueue(requireContext()).add(request);
    }




}
