package com.example.gsb;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class AdminStatsFragment extends Fragment {

    private TextView tvTotalFrais;
    private LinearLayout repartitionContainer, usersContainer;

    public AdminStatsFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_stats, container, false);

        tvTotalFrais = view.findViewById(R.id.tvTotalFrais);
        repartitionContainer = view.findViewById(R.id.repartitionContainer);
        usersContainer = view.findViewById(R.id.usersContainer);

        chargerStats();

        return view;
    }
    private String getRoleLabel(int role) {
        switch (role) {
            case 1: return "Visiteur";
            case 2: return "Comptable";
            case 3: return "Admin";
            default: return "Inconnu";
        }
    }

    private void chargerStats() {
        String url = "http://192.168.136.1:8080/get_statsapi.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            double total = json.getDouble("total_frais");
                            tvTotalFrais.setText("Total des frais : " + total + " €");

                            JSONArray repArray = json.getJSONArray("repartition");
                            repartitionContainer.removeAllViews();
                            for (int i = 0; i < repArray.length(); i++) {
                                JSONObject item = repArray.getJSONObject(i);
                                String type = item.getString("type_frais");
                                double montant = item.getDouble("montant");

                                TextView tv = new TextView(getContext());
                                tv.setText("• " + type + " : " + montant + " €");
                                repartitionContainer.addView(tv);
                            }

                            JSONArray users = json.getJSONArray("utilisateurs");
                            usersContainer.removeAllViews();
                            for (int i = 0; i < users.length(); i++) {
                                JSONObject u = users.getJSONObject(i);
                                String nom = u.getString("fname") + " " + u.getString("lname");
                                String role = getRoleLabel(u.getInt("role"));

                                TextView tv = new TextView(getContext());
                                tv.setText("👤 " + nom + " - " + role);
                                usersContainer.addView(tv);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getContext(), "Erreur réseau", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(requireContext()).add(request);
    }
}
