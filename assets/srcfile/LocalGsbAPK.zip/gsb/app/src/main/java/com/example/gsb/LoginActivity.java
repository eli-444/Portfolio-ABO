package com.example.gsb;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private final String LOGIN_URL = "http://192.168.136.1:8080/loginapi.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin   = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String email = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest request = new StringRequest(Request.Method.POST, LOGIN_URL,
                response -> {
                    Log.e("API_RESPONSE", response);
                    try {
                        JSONObject json = new JSONObject(response);
                        boolean success = json.getBoolean("success");

                        if (success) {
                            JSONObject user = json.getJSONObject("user");
                            String userId = user.getString("id");
                            int role = user.getInt("role");
                            String type = user.optString("type", "visiteur");

                            SharedPreferences prefs = getSharedPreferences("GSB_PREFS", MODE_PRIVATE);
                            SharedPreferences.Editor editor = prefs.edit();

                            editor.putString("id", userId);
                            editor.putString("email", email);
                            editor.putString("role", String.valueOf(role));
                            editor.putString("type", type);

                            editor.apply();

                            Intent intent;
                            if (role == 1) {
                                intent = new Intent(LoginActivity.this, DashboardActivity.class); // visiteur
                            } else if (role == 2) {
                                intent = new Intent(LoginActivity.this, DashboardComptableActivity.class); // comptable
                            } else if (role == 3) {
                                intent = new Intent(LoginActivity.this, DashboardAdminActivity.class); // admin
                            } else {
                                Toast.makeText(this, "Rôle non reconnu", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, "Identifiants incorrects", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Erreur de parsing JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(this, "Erreur réseau", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}
