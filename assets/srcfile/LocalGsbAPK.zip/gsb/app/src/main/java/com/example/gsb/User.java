package com.example.gsb;

public class User {
    private int id;
    private String fname;
    private String lname;
    private String email;
    private int role;
    private String roleLabel;

    public User(int id, String fname, String lname, String email, int role, String roleLabel) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.role = role;
        this.roleLabel = roleLabel;
    }

    public int getId() { return id; }
    public String getFname() { return fname; }
    public String getLname() { return lname; }
    public String getEmail() { return email; }
    public int getRole() { return role; }
    public String getRoleLabel() { return roleLabel; }
}
