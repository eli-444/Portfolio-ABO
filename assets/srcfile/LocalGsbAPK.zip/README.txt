///IMPORTANT///
A executer de manière local parce que bon voila


Prérequis: 
-XAMPP
-AndroidStudio ( oui parce que faut mettre les mains dans le code du coup pour les url des api ^^' )
-BDD "bisounours"
-PhpMyAdmin ( qui va de soit avec la bdd sinon ca marche pas )
-api ( 12 au total + 1 fichier intitulé "connexion.php")

Etapes à suivre pour pouvoir executer l'app mobile:
-Lancer PhpMyAdmin et importer la bdd "bisounours"
-Coller le fichier "apiGSBforAndroid" dans le chemin suivant  
C:\xampp\htdocs

Lancer AndroidStudio, il va falloir modifier quasi toutes les classes java, pas besoin de toucher aux XML.

Les urls reliant les api devraient ressembler à quelque chose de comme ça : "http://1.1.1.1:8080/get_fiche_detailapi.php?"

ce qu'il faut faire , c'est de remplacer simplement l'ip 1.1.1.1 ( ou quelconque autre ip ) par la votre !

tuto rapide pour les plus nuls d'entre vous :

lancer cmd.exe
taper la commande 'ipconfig'
une liste de cartes réseaux devrait apparaitre, choisissez la bonne et séléctionner l'adresse IpV4 qui ressemble à quelque chose comme :

192.168.x.x

voila le travail vous avez votre ip à implémenter dans le code !