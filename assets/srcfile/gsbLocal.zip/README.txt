/////IMPORTANT/////
Pour executer l'application web de manière local, il faut possédé les prérequis suivants : 

- XAMPP
- Base de données "bisounours" ( pas de critique sur le nom )


Etapes à suivre : 

1.Installer xampp si vous ne le posséder pas
2.Déposer le fichier gsbLocal dans le chemin suivant : C:\xampp\htdocs
3.Démarrer phpMyAdmin, se connecter a la base de données et importer bisounours


Voila, normalement en vous connectant de manière local à l'application web
votre url devrait ressembler à ça :

http://localhost:8080
ou
http://localhost:8080/gsbLocal

( la différence dépends de comment votre le root de votre xampp est configuré )
 
maintenantvous devriez pouvoir utiliser l'application de manière fluide.


id et mdp dans le doc "E6SpecABO.odt"