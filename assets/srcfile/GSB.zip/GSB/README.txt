pour faire fonctionner de manière local cette application fiche frais il faut :

installer xampp
start apache
start phpMyAdmin

dans votre PhpMyAdmin, executer la requête suivante : 

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS bisounours;
USE bisounours;

-- Table Role
CREATE TABLE IF NOT EXISTS Role (
    id_role INT AUTO_INCREMENT PRIMARY KEY,
    role VARCHAR(50) NOT NULL
);

-- Table User
CREATE TABLE IF NOT EXISTS User (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role INT NOT NULL,
    FOREIGN KEY (role) REFERENCES Role(id_role) ON DELETE CASCADE
);

-- Table Fiche (avec la colonne `commentaire` ajoutée)
CREATE TABLE IF NOT EXISTS Fiche (
    id_fiche INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    date DATE NOT NULL,
    commentaire TEXT NULL, -- Ajout du commentaire
    FOREIGN KEY (id_user) REFERENCES User(id_user) ON DELETE CASCADE
);

-- Table Type_Frais (Les types de frais disponibles)
CREATE TABLE IF NOT EXISTS Type_Frais (
    id_lf INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL
);

-- Table Ligne_Frais (les dépenses associées aux fiches)
CREATE TABLE IF NOT EXISTS Ligne_Frais (
    id_lf INT AUTO_INCREMENT PRIMARY KEY,
    id_fiche INT NOT NULL,
    id_typefrais INT NOT NULL,
    quantite DECIMAL(10,2) NOT NULL,
    date_depense DATE NOT NULL,
    justificatif VARCHAR(255) NULL,
    FOREIGN KEY (id_fiche) REFERENCES Fiche(id_fiche) ON DELETE CASCADE,
    FOREIGN KEY (id_typefrais) REFERENCES Type_Frais(id_lf) ON DELETE CASCADE
);

-- Insertion des rôles
INSERT INTO Role (role) VALUES 
('Visiteur'),
('Comptable'),
('Administrateur');

-- Insertion des types de frais
INSERT INTO Type_Frais (type) VALUES 
('Hebergement'),
('Transport'),
('Dejeuner'),
('Diner'),
('Hors forfait');


