import pygame
from game import Game

pygame.init()

# Définition de la fenêtre
pygame.display.set_caption("Goku 2D")
screen = pygame.display.set_mode((1600, 900))

# Charger l'arrière-plan
background = pygame.image.load('assets/assets/wow.jpg')

# Charger l’image du titre
title_image = pygame.image.load('assets/assets/gokucellmenu.png')
title_image = pygame.transform.scale(title_image, (1000, 800))  # Redimensionner si nécessaire
title_rect = title_image.get_rect(center=(800, 450))  # Position en haut au centre

# Charger et redimensionner l’image du bouton Start
start_button_image = pygame.image.load('assets/assets/start.png')
start_button_image = pygame.transform.scale(start_button_image, (200, 80))  # Taille ajustée
start_button_rect = start_button_image.get_rect(center=(800, 800))  # Position en bas

# 🎮 **Fonction pour afficher le menu principal**
def main_menu():
    """Affiche le menu principal avec Start"""
    menu = True
    while menu:
        screen.blit(background, (0, 0))
        screen.blit(title_image, title_rect)
        screen.blit(start_button_image, start_button_rect)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start_button_rect.collidepoint(event.pos):
                    menu = False  # ✅ Quitter le menu et démarrer le jeu

# 🎮 **Fonction pour afficher l'écran Game Over**
def game_over_screen():
    """Affiche l'écran Game Over avec une image et un bouton Restart"""
    game_over_image = pygame.image.load('assets/assets/gameover.png')
    restart_image = pygame.image.load('assets/assets/restart.png')

    game_over_image = pygame.transform.scale(game_over_image, (800, 700))
    restart_image = pygame.transform.scale(restart_image, (250, 100))

    game_over_rect = game_over_image.get_rect(center=(screen.get_width() // 2, 250))
    restart_rect = restart_image.get_rect(center=(screen.get_width() // 2, 800))

    while True:
        screen.blit(background, (0, 0))
        screen.blit(game_over_image, game_over_rect)
        screen.blit(restart_image, restart_rect)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if restart_rect.collidepoint(event.pos):
                    return True  # ✅ Redémarrer la partie

# 🚀 **Démarrer le jeu après le menu principal**
while True:  # 🔁 Garder une boucle infinie pour gérer Restart
    main_menu()  # ✅ Afficher le menu principal

    # ✅ Créer une nouvelle instance du jeu après avoir quitté le menu
    game = Game()
    running = True

    while running:
        screen.blit(background, (0, 0))

        # 🎯 Vérifier et enregistrer les touches pressées AVANT de gérer les mouvements
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                game.pressed[event.key] = True  # ✅ Enregistre la touche pressée
                if event.key == pygame.K_SPACE:
                    game.player.launch_projectile()  # ✅ Le joueur tire
            elif event.type == pygame.KEYUP:
                game.pressed[event.key] = False  # ✅ Marque la touche comme relâchée

        # 🎯 Appliquer les déplacements APRÈS avoir mis à jour `game.pressed`
        if game.pressed.get(pygame.K_RIGHT) and game.player.rect.x + game.player.rect.width < screen.get_width():
            game.player.move_right()
        if game.pressed.get(pygame.K_LEFT) and game.player.rect.x > 0:
            game.player.move_left()
        if game.pressed.get(pygame.K_UP) and game.player.rect.y > 0:
            game.player.move_up()
        if game.pressed.get(pygame.K_DOWN) and game.player.rect.y + game.player.rect.height < screen.get_height():
            game.player.move_down()

        # Affichage du joueur
        screen.blit(game.player.image, game.player.rect)
        game.player.update_health_bar(screen)

        # Gérer l'apparition des monstres
        game.spawn_monster()

        # Afficher et mettre à jour les monstres existants
        for monster in list(game.all_monsters):  # ✅ Convertir en liste pour éviter des erreurs de suppression
            monster.forward()
            monster.update_health_bar(screen)
            monster.update()
            screen.blit(monster.image, monster.rect)

        # Gérer les projectiles
        for projectile in game.all_projectiles:
            projectile.move()
            screen.blit(projectile.image, projectile.rect)  # ✅ Afficher chaque projectile

        pygame.display.flip()

        # Vérifier si le joueur est mort
        if game.player.health <= 0:
            running = False  # ⛔ Arrêter le jeu et afficher l'écran Game Over

    # 🎯 Quand le joueur meurt, afficher l'écran Game Over et redémarrer si besoin
    if not game_over_screen():
        pygame.quit()
        exit()  # ✅ Quitter complètement si l'utilisateur ne veut pas recommencer
