import pygame

class Projectile(pygame.sprite.Sprite):

    def __init__(self, shooter):
        super().__init__()
        self.shooter = shooter
        self.velocity = 5 if type(shooter).__name__ == "Monster" else 10  # Vitesse différente pour le monstre et le joueur
        self.image = pygame.image.load('assets/assets/projectile.png')
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.x = shooter.rect.x + (100 if type(shooter).__name__ == "Player" else -50)
        self.rect.y = shooter.rect.y + 50
        self.direction = 1 if type(shooter).__name__ == "Player" else -1

    def move(self):
        """Déplacement des projectiles et suppression quand ils sortent de l'écran"""
        self.rect.x += self.velocity * self.direction

        # ✅ Vérifier si le projectile sort de l'écran
        if self.rect.right < 0 or self.rect.left > 1600:
            self.remove()  # ✅ Supprimer le projectile


        # ✅ Vérifier collision avec le joueur
        if type(self.shooter).__name__ == "Monster":  # Si le tireur est un monstre
            if pygame.sprite.collide_rect(self, self.shooter.game.player):
                self.remove()
                self.shooter.game.player.take_damage(self.shooter.attack)  # ✅ Plus besoin d'importer Player

        # ✅ Vérifier collision avec un monstre
        elif type(self.shooter).__name__ == "Player":  # Si le tireur est un joueur
            for monster in self.shooter.game.check_collision(self, self.shooter.game.all_monsters):
                self.remove()
                monster.damage(self.shooter.attack)

        # Supprimer le projectile s'il sort de l'écran
        if self.rect.x < 0 or self.rect.x > 1600:
            self.remove()


def remove(self):
    """Supprime le projectile du jeu"""
    self.shooter.all_projectiles.remove(self)
    self.shooter.game.all_projectiles.remove(self)  # ✅ Supprime aussi du groupe global
