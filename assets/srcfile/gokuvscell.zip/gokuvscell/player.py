import pygame
from projectile import Projectile
from monster import Monster


# première classe qui va représenter le joueur
class Player(pygame.sprite.Sprite):

    def __init__(self, game):
        super().__init__()
        self.game = game
        self.health = 100
        self.max_health = 100
        self.attack = 80
        self.velocity = 8
        self.all_projectiles = pygame.sprite.Group()
        self.image = pygame.image.load('assets/assets/goku.png')
        self.rect = self.image.get_rect()
        self.rect.x = 400
        self.rect.y = 500

    def update_health_bar(self, surface):
        """Affiche la barre de vie du joueur"""
        bar_color = (0, 255, 0) if self.health > 40 else (255, 0, 0)  # Rouge si < 40 HP
        background_bar = (50, 50, 50)
        bar_position = [self.rect.x + 10, self.rect.y - 20, self.health, 5]
        background_position = [self.rect.x + 10, self.rect.y - 20, self.max_health, 5]

        pygame.draw.rect(surface, background_bar, background_position)
        pygame.draw.rect(surface, bar_color, bar_position)

    def take_damage(self, amount):
        """Réduit la vie du joueur et affiche Game Over si la vie tombe à 0"""
        self.health -= amount
        print(f"Le joueur a perdu {amount} points de vie. Vie restante : {self.health}")

        if self.health <= 0:
            print("GAME OVER !")
            self.game.running = False  # ✅ Indique que le jeu est terminé



    def launch_projectile(self):
        """Le joueur tire"""
        projectile = Projectile(self)
        self.all_projectiles.add(projectile)  # Ajoute au groupe de projectiles du joueur
        self.game.all_projectiles.add(projectile)  # ✅ Ajoute au groupe global pour l'affichage



    def move_right(self):
        # si le joueur n'est pas en collison avec l'objet monstre
        if not self.game.check_collision(self, self.game.all_monsters):
            self.rect.x += self.velocity

    def move_left(self):
        self.rect.x -= self.velocity

    def move_up(self):
        self.rect.y -= self.velocity

    def move_down(self):
        self.rect.y += self.velocity
