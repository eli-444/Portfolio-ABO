import pygame
from player import Player
from monster import Monster


# creer une seconde classe qui va représenter le jeu
class Game:

    def __init__(self):
        self.all_players = pygame.sprite.Group()
        self.player = Player(self)
        self.all_players.add(self.player)
        self.all_monsters = pygame.sprite.Group()
        self.all_projectiles = pygame.sprite.Group()
        self.pressed = {}
        self.spawn_monster_timer = pygame.time.get_ticks()

    def spawn_monster(self):
        """Fait apparaître un monstre toutes les 3 secondes, avec une limite"""
        if len(self.all_monsters) < 5:  # ✅ Empêche d'avoir trop de monstres actifs
            now = pygame.time.get_ticks()
            if now - self.spawn_monster_timer > 3000:
                monster = Monster(self)
                self.all_monsters.add(monster)
                self.spawn_monster_timer = now  # ✅ Réinitialise le timer


    def check_collision(self, sprite, group):  # ✅ Correction du nom
        """Vérifie les collisions"""
        return pygame.sprite.spritecollide(sprite, group, False, pygame.sprite.collide_mask)


    def update(self, screen):
        # Affichage des projectiles du monstre
        for monster in self.all_monsters:
            monster.update()  # Vérifier si le monstre doit tirer
            for projectile in monster.all_projectiles:
                projectile.move()

        # Dessiner les projectiles
        self.all_projectiles.draw(screen)


   
