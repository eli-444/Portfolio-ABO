import pygame
import random

class Monster(pygame.sprite.Sprite):

    def __init__(self, game):
        super().__init__()
        self.game = game
        self.health = 100
        self.maxhealth = 100
        self.attack = 1  # Dégâts infligés au joueur
        self.image = pygame.image.load('assets/assets/monstre.png')
        self.all_projectiles = pygame.sprite.Group()
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(1200, 1600)  # Spawn aléatoire hors écran à droite
        self.rect.y = random.randint(100, 700)  # Position verticale aléatoire
        self.velocity = random.uniform(1, 8)  # Vitesse entre 1 et 3 pixels par frame
        self.last_shoot = pygame.time.get_ticks()
        self.shoot_delay = random.randint(2000, 4000)  # Tir entre 2 et 4 secondes

    def damage(self, amount):
        """Réduit la vie du monstre et le supprime si sa vie tombe à 0"""
        self.health -= amount
        if self.health <= 0:
            self.remove()
            print("Monstre éliminé")

    def update_health_bar(self, surface):
        """Affiche la barre de vie du monstre"""
        bar_color = (255, 0, 0)
        background_bar = (50, 50, 50)
        bar_position = [self.rect.x + 10, self.rect.y - 20, self.health, 5]
        background_position = [self.rect.x + 10, self.rect.y - 20, self.maxhealth, 5]

        pygame.draw.rect(surface, background_bar, background_position)
        pygame.draw.rect(surface, bar_color, bar_position)

    def forward(self):
        """Déplace le monstre vers la gauche et le supprime s'il quitte l'écran"""
        if self.rect.right < 0:  # ✅ Si le monstre sort de l'écran, on le supprime
            self.remove()
        elif not self.game.check_collision(self, self.game.all_players):
            self.rect.x -= self.velocity  # Avancer vers la gauche
        else:
            self.game.player.take_damage(self.attack)  # Infliger des dégâts si le monstre touche le joueur

    def remove(self):
        """Supprime le monstre du jeu"""
        self.game.all_monsters.remove(self)


    def update(self):
        """Gestion du tir des projectiles"""
        now = pygame.time.get_ticks()
        if now - self.last_shoot > self.shoot_delay:
            self.shoot_projectile()
            self.last_shoot = now
            self.shoot_delay = random.randint(2000, 4000)

    def shoot_projectile(self):
        """Le monstre tire plusieurs projectiles"""
        from projectile import Projectile  # Import différé pour éviter les erreurs
        for _ in range(2):  # Tire 2 projectiles à chaque tir
            projectile = Projectile(self)
            self.all_projectiles.add(projectile)
            self.game.all_projectiles.add(projectile)

